<?php

return array(

    'titulo' => 'CONTÁCTANOS',
    'nombre' => 'Nombre:',
    'email' => 'Email:',
    'mensaje' => 'Mensaje:',
    'btnEnviar' => 'ENVIAR',

    'ubicanos' => 'UBÍCANOS',
    'direccion' => 'Dirección:',
    'telefono' => 'Teléfono:',
    'header' => 'SU OPINIÓN ES MUY IMPORTANTE PARA NOSOTROS'

);
