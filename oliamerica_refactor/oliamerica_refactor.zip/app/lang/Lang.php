<?php


class Lang {

	static $lenguaje = 'es';

	public static function get($nombreVariable){
		$array = self::obtenerDataArchivo($nombreVariable);
		$nombreVariable = explode('.', $nombreVariable)[1];
		return $array[$nombreVariable];
	}

	private static function obtenerDataArchivo($nombreVariable){
		$nombreArchivo = explode('.', $nombreVariable);
		return include self::$lenguaje . '/' . $nombreArchivo[0] . '.php';
	}
}