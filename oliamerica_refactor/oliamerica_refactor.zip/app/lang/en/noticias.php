<?php

return array(

    /*
    |--------------------------------------------------------------------------
    | Password Reminder Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'tituloNoticias' => 'LAST NEWS',
    'titulo1' => 'Titulo Noticia',
    'titulo2' => 'Titulo Noticia',
    'titulo3' => 'Titulo Noticia',
    'titulo4' => 'Titulo Noticia',
    'titulo5' => 'Titulo Noticia',
    'titulo6' => 'Titulo Noticia'

);
