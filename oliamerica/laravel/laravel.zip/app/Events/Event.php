<?php

namespace oliamerica\Events;

abstract class Event
{
    //
}
