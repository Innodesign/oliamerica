<?php

require 'Slim/Slim.php';

require 'app/lang/Lang.php';

\Slim\Slim::registerAutoloader();


$app = new \Slim\Slim([
	'templates.path' => 'views'
]);

$app->get("/", function() use ($app){
	$app->render('index.php');
});


$app->render('header.php');

$app->run();

$app->render('footer.php');
