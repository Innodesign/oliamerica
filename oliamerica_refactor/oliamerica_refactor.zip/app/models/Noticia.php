<?php

class Noticia extends ActiveRecord\Model{
	
}